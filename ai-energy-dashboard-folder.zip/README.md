AI Energy Dashboard - Project README
